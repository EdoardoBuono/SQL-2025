CREATE database toysgroup; #creo il database
use toysgroup; #uso il database

#task 2 creo le tabelle
CREATE TABLE region (
	id_region INT AUTO_INCREMENT PRIMARY KEY,
    nomeregion VARCHAR (60) 
    );
    
CREATE TABLE category (
	id_category INT AUTO_INCREMENT PRIMARY KEY,
    nomecategoria VARCHAR (60) ,
    nomesottocategoria VARCHAR (60) 
    );
    
CREATE TABLE product (
	id_product INT AUTO_INCREMENT PRIMARY KEY,
    nomeprodotto VARCHAR (60) ,
	colore VARCHAR (60) ,
    prezzoprodotto DECIMAL (10,2),
    quantitapresente INT,
    id_category INT,
    FOREIGN KEY(id_category) REFERENCES category(id_category)
    );
    
CREATE TABLE country (
	id_country INT AUTO_INCREMENT PRIMARY KEY,
    nomecountry VARCHAR (60),
    id_region INT,
    FOREIGN KEY(id_region) REFERENCES region(id_region)
    );
    
CREATE TABLE Sales (
	id_sales INT AUTO_INCREMENT PRIMARY KEY,
    cliente VARCHAR (60),
    dataordine DATE,
    quantitavenduta INT,
    prezzounitario DECIMAL (10,2),
    totalevendita DECIMAL(10,2),
    id_product INT,
    id_country INT,
    FOREIGN KEY (id_product) REFERENCES product(id_product),
    FOREIGN KEY (id_country) REFERENCES country(id_country)
    );
    
#task 4 popolo le tabelle 
INSERT INTO Region(nomeregion) VALUES
('Europa'),
('Nord America'),
('Asia'),
('Africa'),
('Oceania');

INSERT INTO Category (nomecategoria,nomesottocategoria) VALUES
('Giochi Educativi', 'Matematica'),
('Giochi Creativi', 'Disegno'),
('Bambole e Action Figure', 'Principesse'),
('Veicoli', 'Aerei giocattolo'),
('Giochi da Tavolo', 'Strategia Leggera');

INSERT INTO Product (nomeprodotto,colore,prezzoprodotto,quantitapresente,id_category) VALUES
('Puzzle Numerico 50 pezzi', 'Multicolore', 4.50, 5, 1),
('Kit Disegno Junior', 'Blu', 3.90, 4, 2),
('Bambola Principessa Luna', 'Rosa', 5.00, 3, 3),
('Aereo Giocattolo Mini Jet', 'Rosso', 4.80, 2, 4),
('Monopoli', 'Verde', 3.50, 5, 5);

INSERT INTO Country (nomecountry,id_region) VALUES
('Italia', 1),
('Canada', 2),
('Giappone', 3),
('Egitto', 4),
('Australia', 5);

INSERT INTO Sales (cliente,dataordine,quantitavenduta,prezzounitario,totalevendita,id_product,id_country) VALUES
('Luca Bianchi', '2024-10-20', 2, 4.50, 9.00, 1, 1),
('Marie Tremblay', '2025-10-21', 3, 3.90, 11.70, 2, 2),
('Kenji Sato', '2025-10-22', 2, 5.00, 10.00, 3, 3),
('Amina Hassan', '2025-10-23', 3, 4.80, 14.40, 4, 4),
('Liam Wilson', '2025-10-24', 2, 3.50, 7.00, 5, 5);
select * from sales;

#task 4
#4.1 verifico che le chiavi primarie siano univoche e senza duplicati
#delle tabelle region category product country sales

SELECT id_region,
	COUNT(*)
FROM region
GROUP BY id_region
HAVING count(*)>1;

SELECT id_category,
	COUNT(*)
FROM category
GROUP BY id_category
HAVING count(*)>1;

SELECT id_product,
	COUNT(*)
FROM product
GROUP BY id_product
HAVING count(*)>1;

SELECT id_country,
	COUNT(*)
FROM country
GROUP BY id_country
HAVING count(*)>1;

SELECT id_sales,
	COUNT(*)
FROM sales
GROUP BY id_sales
HAVING count(*)>1;

#4.2
#Esporre l’elenco delle transazioni indicando nel result set il codice documento, 
#la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, 
#il nome della regione di vendita e un campo booleano valorizzato
 #in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno 
 #(>180 -> True, <= 180 -> False)
 
 SELECT
 s.id_sales AS codiceDocumento,
 s.dataordine,
 p.nomeprodotto,
 c.nomecategoria,
 cou.nomecountry AS nomeNazione,
 r.nomeregion AS continenteVendita,
 IF (DATEDIFF('2025-10-31', s.dataordine) >180, 'true', 'false') as piùdi180giorni
 FROM sales AS s
 INNER JOIN product AS p
ON s.id_product=p.id_product
INNER JOIN category AS c
ON p.id_category=c.id_category
INNER JOIN country as cou
ON s.id_country=cou.id_country
INNER JOIN region as r
ON cou.id_region=r.id_region;

#4.3 
#Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media
 #delle vendite realizzate nell’ultimo anno censito. (ogni valore della condizione deve risultare
 #da una query e non deve essere inserito a mano). Nel result set devono comparire solo
 #il codice prodotto e il totale venduto.
 
 SELECT
 id_product,
 SUM(totalevendita) AS totaleFatturato
 FROM sales
 WHERE YEAR(dataordine)=(SELECT MAX(YEAR(dataordine))FROM sales)
 GROUP BY id_product
 HAVING SUM(quantitavenduta)>(SELECT AVG(quantitavenduta)FROM sales);
 
 #4.4
#Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno

SELECT
s.id_product,
p.nomeprodotto,
YEAR(s.dataordine) AS anno,
SUM(s.totalevendita) AS fatturatoTotale
FROM sales as s
INNER JOIN product AS p
ON s.id_product=p.id_product
GROUP BY s.id_product,
p.nomeprodotto,
YEAR(s.dataordine);

#4.5)
#Esporre il fatturato totale per stato per anno. Ordina il risultato per data
# e per fatturato decrescente.

SELECT
cou.nomecountry AS nomeStato,
YEAR(s.dataordine) AS anno,
SUM(totalevendita) AS fatturatoTotale
FROM sales AS s
INNER JOIN country AS cou
ON s.id_country=cou.id_country
GROUP BY cou.nomecountry,
YEAR(s.dataordine)
ORDER BY 
anno,
fatturatoTotale DESC;

#4.6
#Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato

SELECT
c.nomecategoria AS categoria,
SUM(s.quantitavenduta) AS totaleQuantitaVenduta
FROM sales AS s
INNER JOIN product as p
ON s.id_product=p.id_product
INNER JOIN category AS c
ON p.id_category=c.id_category
GROUP BY c.nomecategoria
ORDER BY totaleQuantitaVenduta DESC;

#4.7
#Rispondere alla seguente domanda: quali sono i prodotti invenduti?
#Proponi due approcci risolutivi differenti
#PRIMO APPROCCIO CON SUBQUERY ( i miei prodotti sono tutti venduti quindi non dovranno uscire)
SELECT 
nomeprodotto
FROM product
WHERE id_product NOT IN (
    SELECT id_product
    FROM sales
);

#SECONDO APPROCCIO CON LEFT JOIN (i miei prodotti sono tutti venduti quindi non dovranno uscire)
#USO LEFT PERCHè SE CI FOSSERO STATI DEI PRODOTTI NON VENDUTI MI SAREBBERO APPARSI
SELECT 
p.id_product AS codiceProdotto,
p.nomeprodotto
FROM product AS p
LEFT JOIN sales as s
ON p.id_product=s.id_product
WHERE s.id_sales IS NULL;

#4.8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” 
#delle informazioni utili (codice prodotto, nome prodotto, nome categoria)

CREATE VIEW versione_denormalizzata_prodotti
AS (
SELECT
p.id_product AS codiceProdotto,
p.nomeprodotto AS nome,
c.nomecategoria AS categoria
FROM product AS p
INNER JOIN category as c
ON p.id_category=c.id_category
);

SELECT * FROM versione_denormalizzata_prodotti;


#4.9)Creare una vista per le informazioni geografiche
CREATE VIEW informazioni_geografiche
AS (
SELECT 
s.id_sales AS codiceVendita,
s.dataordine AS dataordine,
cou.nomecountry AS nazione,
r.nomeregion AS continente,
p.id_product AS codiceProdotto,
p.nomeprodotto AS nomeProdotto
FROM sales AS s
INNER JOIN product AS p
ON s.id_product=p.id_product
INNER JOIN country AS cou
ON s.id_country=cou.id_country
INNER JOIN region AS r
ON cou.id_region=r.id_region
);

SELECT * FROM informazioni_geografiche;